<?php include './files/connection.php' ?>
<?php 
$name = $_POST['name'];
$email = $_POST['email'];
$Address = $_POST['Address'];
$City = $_POST['City'];
$State = $_POST['State'];
$Zip = $_POST['Zip'];
$queries = $_POST['queries'];

// echo "$name,$email,$Address,$City,$State,$Zip,$queries";


$query_i = "insert into contact(Name,Email,Address,City,State,ZipCode,Queries) values('$name','$email','$Address','$City','$State','$Zip','$queries')";
			$result_i = mysqli_query($conn,$query_i);

			echo "<script>alert('Your Query has Been recorded..')</script>";
?>