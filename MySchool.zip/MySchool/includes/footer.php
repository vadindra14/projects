    <!-- bootstrap and jquery  javascript links -->
    <script src="../bootstrap4/jquery.min.js"></script>
    <script src="../bootstrap4/bootstrap.min.js"></script>
    <script src="https://unpkg.com/ionicons@5.2.3/dist/ionicons.js"></script>
  </body>
</html>