<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../Bootstrap4/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../Stylesheets/style.css">
    <link rel="stylesheet" type="text/css" href="../Stylesheets/fonts.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>School | HOME</title>
  </head>
  <body>