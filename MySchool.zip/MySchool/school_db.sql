-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 06:00 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `Class` int(11) NOT NULL,
  `Section` varchar(2) NOT NULL,
  `Class_Teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`Class`, `Section`, `Class_Teacher_id`) VALUES
(0, 'A', 1),
(10, 'A', 4),
(10, 'B', 3),
(9, 'B', 1),
(9, 'A', 2),
(8, 'A', 7),
(8, 'B', 6);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `Name` varchar(80) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(30) NOT NULL,
  `State` varchar(30) NOT NULL,
  `ZipCode` varchar(10) NOT NULL,
  `Queries` varchar(255) NOT NULL,
  `C_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Name`, `Email`, `Address`, `City`, `State`, `ZipCode`, `Queries`, `C_id`) VALUES
('ravi', 'ravi@gmail.com', 'sainagar road', 'hubballi', 'Karnataka', '580063', 'i have nothing to ask', 1);

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `F_id` int(11) NOT NULL,
  `F_FName` varchar(100) NOT NULL,
  `F_LName` varchar(100) NOT NULL,
  `F_Mail` varchar(100) NOT NULL,
  `F_Sub` varchar(60) NOT NULL,
  `F_ASub` varchar(60) NOT NULL,
  `F_Phone` varchar(11) NOT NULL,
  `F_Class` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`F_id`, `F_FName`, `F_LName`, `F_Mail`, `F_Sub`, `F_ASub`, `F_Phone`, `F_Class`) VALUES
(1, 'Sunita', 'Chavan', 'SunitaCh@gmail.com', 'Physics', '--', '9089786857', 9),
(2, 'Rajesh ', 'Patil', 'PatilRajesh@gmail.com', 'Mathematics', '--', '9008776521', 9),
(3, 'Shreya', 'Krishnaji', 'ShreyaK@gmail.com', 'Chemistry', 'English', '7886885432', 10),
(4, 'Mutturaj', 'Halemani', 'Muttu456@gmamil.com', 'Physical Education (P.E)', 'Sanskrit', '8997990002', 10),
(5, 'Shivanand', 'Badiger', 'ShivyaBadi87@gmail.com', 'Chemistry', 'Kannada', '9580786257', 10),
(6, 'Rama', 'Dsouza', 'RamaDsouza@gmail.com', 'English', '--', '9934567890', 8),
(7, 'Rakesh', 'Mathad', 'Rakesh78@gmail.com', 'Mathematics', 'English', '9039788857', 8);

-- --------------------------------------------------------

--
-- Table structure for table `s_info`
--

CREATE TABLE `s_info` (
  `s_id` int(11) NOT NULL,
  `s_fname` varchar(20) NOT NULL,
  `s_lname` varchar(20) NOT NULL,
  `s_faname` varchar(20) NOT NULL,
  `s_moname` varchar(20) NOT NULL,
  `s_email` varchar(60) NOT NULL,
  `s_phno` varchar(11) NOT NULL,
  `s_class` int(2) NOT NULL,
  `s_lang` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `s_info`
--

INSERT INTO `s_info` (`s_id`, `s_fname`, `s_lname`, `s_faname`, `s_moname`, `s_email`, `s_phno`, `s_class`, `s_lang`) VALUES
(1, 'rakesh', 'shanbhag', 'anil', 'roopa', 'rakeshshan1234@gmail.com', '6365890132', 10, 'Sanskrit'),
(2, 'prajwal', 'godkindi', 'vijay', 'radha', 'prajwalpraj88@gmail.com', '7689878677', 8, 'kannada'),
(3, 'aardhya', 'hiremath', 'ramprakash', 'manjula', 'aaradhya567@gmail.com', '9988779762', 8, 'Hindi'),
(4, 'ravi', 'shastri', 'madhav ', 'rohini', 'ravi123@gmail.com', '9988776651', 10, 'Kannada'),
(5, 'rohit', 'shinde', 'madhavrao', 'pranita', 'rohit1907@gmail.com', '6748939348', 8, 'Hindi'),
(6, 'naina', 'kulkarni', 'naveen', 'shraavani', 'naina34200@gmail.com', '7899652311', 10, 'kannada'),
(7, 'sahil', 'jain', 'arihant', 'vasavi', 'sahil2000@gmail.com', '9988770003', 8, 'Sanskrit'),
(8, 'karthik', 'agadi', 'Rajshekhar', 'sonia', 'karthikboss@gmail.com', '8667900345', 10, 'kannada'),
(9, 'harish', 'kulgod', 'Ramesh', 'anjali', 'harrykulod@gmail.com', '8907656643', 9, 'Hindi'),
(10, 'pranav', 'kotur', 'sriram', 'praneeta', 'pranav78665@gmail.com', '7866542311', 10, 'Kannada'),
(11, 'amruta', 'mitagar', 'Niranjan', 'Vimala', 'amrutamitagar78@gmail.com', '9900786543', 9, 'Hindi'),
(12, 'abhishek', 'chowkimath', 'gajendra', 'savita', 'abhi1290@gmail.com', '9988776650', 8, 'Hindi'),
(13, 'malhar', 'jadhav', 'rakesh', 'maadhvi', 'malharjadhav@gmail.com', '8667900372', 10, 'kannada'),
(14, 'namrata', 'hiremath', 'Ramesh', 'jaya', 'namrata29@gmail.com', '8907656600', 9, 'sanskrit'),
(15, 'neha', 'deshpande', 'manoj', 'praneeta', 'nehadep@gmail.com', '7866542002', 8, 'sanskrit');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'supreet', 'sup3652'),
(2, 'Vaadhu', 'bhaai');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD KEY `test` (`Class_Teacher_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`C_id`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`F_id`);

--
-- Indexes for table `s_info`
--
ALTER TABLE `s_info`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `C_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `F_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `s_info`
--
ALTER TABLE `s_info`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `test` FOREIGN KEY (`Class_Teacher_id`) REFERENCES `faculties` (`F_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
