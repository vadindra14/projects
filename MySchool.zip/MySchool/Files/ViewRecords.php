<?php include './connection.php';?>
<!DOCTYPE html>
<html>
<head>
	<title></title>

	<?php include '../includes/header.php'; 
      	  include '../includes/footer.php';
    ?>

</head>
<body class="bg-light">

	<div class="container p-4 text-monospace">
		<h2 class="display-4 p-4">Students currently studying in school are:</h2>
		<table class="table table-responsive table-hover text-center">
			<thead class="thead-dark">
				<tr>
					<th>Student id</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Father Name</th>
					<th>Mother Name</th>
					<th>Phone no.</th>
					<th>Class</th>
					<th>chosen Language</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$selectquery = "select * from s_info";
				$query = mysqli_query($conn,$selectquery);
				$nums = mysqli_num_rows($query);

				while ($res = mysqli_fetch_array($query)) {
				?>
					<tr>
					<td><?php echo $res['s_id'] ?></td>
					<td><?php echo $res['s_fname'] ?></td>
					<td><?php echo $res['s_lname'] ?></td>
					<td><?php echo $res['s_faname'] ?></td>
					<td><?php echo $res['s_moname'] ?></td>
					<td><?php echo $res['s_email'] ?></td>
					<td><?php echo $res['s_class'] ?></td>
					<td><?php echo $res['s_lang'] ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>

	

</body>
</html>