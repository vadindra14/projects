<?php include 'connection.php';
$username = $_POST['user'];
$password = $_POST['pass'];


$query = "select * from users where username = '$username' and password = '$password'";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
$count	= mysqli_num_rows($result);

if ($count == 1) {
	echo "<h1><center>logged in successfully<center></center></h1>";
	header("Location:./db_operations_page.php");
	exit();

}else{
	echo "<h1>Login Failed.Invalid username or password</h1>";
}

?>