<?php include 'connection.php';
	$username1 = $_POST['suser'];
	$password1 = $_POST['spass'];
	$password2 = $_POST['scpass'];

	if ($password1 != $password2) {
		echo '<script>	alert("passwords do not match")</script>';
		echo "<h1>Please confirm password again";
		
	}else{

		$query = "select * from users where username = '$username1' and password = '$password1'";
		$result = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
		$count	= mysqli_num_rows($result);

		if ($count == 1) {
		// echo "<h1><center>logged in successfully<center></center></h1>";
		echo "<script>alert('User already exists..Please head back to sign up and enter a different user name')</script>";

		}else{
			$query1 = "insert into users(username,password) values('$username1','$password1')";
			$result1 = mysqli_query($conn,$query1);

			echo "<script>alert('new user added..now you can login')</script>";
		}
	}



?>