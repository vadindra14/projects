<?php include 'connection.php'; ?>
<?php 
$sfname = $_POST['sfname'];
$slname = $_POST['slname'];
$sfaname = $_POST['sfaname'];
$smoname = $_POST['smoname'];
$semail = $_POST['semail'];
$sphone	= $_POST['sphone'];
$sclass = $_POST['sclass'];
$slang = $_POST['slang'];


	// echo"$sfname,$slname,$sfaname,$smoname,$semail,$sphone,$sclass,$slang";
	$query = "select * from s_info where s_fname = '$sfname' and s_lname = '$slname'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$count	= mysqli_num_rows($result);

		if ($count == 1) {
		echo "<script>alert('student is already registered..')</script>";
		}else{
			$query_i = "insert into s_info(s_fname,s_lname,s_faname,s_moname,s_email,s_phno,s_class,s_lang) values('$sfname','$slname','$sfaname','$smoname','$semail','$sphone','$sclass','$slang')";
			$result_i = mysqli_query($conn,$query_i);

			echo "<script>alert('new Student is registered successfully..')</script>";			
		}

?>