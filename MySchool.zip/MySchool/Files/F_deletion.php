<?php include 'connection.php'; ?>
<?php 
$faculty_id = $_POST['fac_id'];
// echo "$faculty_id";
$query = "select * from faculties where F_id = '$faculty_id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$count	= mysqli_num_rows($result);

			if($count==0){
				echo "<script>alert('no such record exists..')</script>";
			}else{
				// echo "record deleted successfully";

				$query_d = "delete from faculties where F_id = '$faculty_id'";
				$result_d = mysqli_query($conn,$query_d);

				echo "<script>alert('Faculty record has been deleted..')</script>";
			}

?>