<?php 
include '../includes/header.php'; 
include './connection.php';?>
<link rel="stylesheet" type="text/css" href="../stylesheets/styles_bg.css?v=<?php echo time(); ?>">

<div class="container db-bg">
		<p class="display-2 text-light text-monospace text-center">Welcome to admin page</p>
		<div class="row">
			<div class="col-md-6">
			<div class="card">
			  <img src="../assets/images/card1.jpg" class="card-img-top" alt="...">
			  <div class="card-body">
			    <h5 class="card-title">Student</h5>
			    <p class="card-text">Perform Admin operations on students</p>
			  </div>
		  
		

		<div class="container">
			<p class="p-2">
				<a class="btn btn-danger" data-toggle="collapse" href="#insertion">Insert</a>
				<a class="btn btn-danger" data-toggle="collapse"	href="#deletion">Delete</a>
				<a class="btn btn-danger" data-toggle="collapse"	href="#View">View Records</a>
			</p>


			<form action="insertion.php" method="post">
				<div class="collapse bg-light p-5 m-3 rounded" id="insertion">
					<h2 class="display-4 text-monospace">Enter the details of the student to be added</h2>
					<div class="form-group">
						<label for="sfname">Enter Student's First Name:</label>
						<input type="text" name="sfname" class="form-control" id="sfname" required>
					</div>
					<div class="form-group">
						<label for="slname">Enter Student's Last Name:</label>
						<input type="text" name="slname" class="form-control" id="slname" required>
					</div>
					<div class="form-group">
						<label for="sfaname">Enter Father's Name:</label>
						<input type="text" name="sfaname" class="form-control" id="sfaname" required>
					</div>
					<div class="form-group">
						<label for="smoname">Enter Mother's Name:</label>
						<input type="text" name="smoname" class="form-control" id="smoname" required>
					</div>
					<div class="form-group">
						<label for="semail">Enter email:</label>
						<input type="email" name="semail" class="form-control" id="semail" required>
					</div>
					<div class="form-group">
						<label for="sphone">Enter Phone no:</label>
						<input type="phone" name="sphone" class="form-control" id="sphone" required>
					</div>
					<div class="form-group">
						<label for="sclass">Select class:</label>
						<select id="sclass" class="form-control" name="sclass">
							<option selected>8</option>
							<option>9</option>
							<option>10</option>
						</select>
					</div>
					<div class="form-group">
						<label for="slang">Select language:</label>
						<select id="slang" class="form-control" name="slang">
							<option selected>Kannada</option>
							<option>Hindi</option>
							<option>Sanskrit</option>
						</select>
					</div>
					<button type="submit" class="btn btn-success">submit</button>
				</div>
			</form>

			<form action="deletion.php" method="post">
				<div class="collapse bg-light p-5 m-3 rounded" id="deletion">
					<h2 class="display-4 text-monospace">Enter the details of the student to be deleted from the database</h2>
					<div class="form-group">
						<label for="d_sid">Enter Roll no of student:</label>
						<input type="text" class="form-control" name="d_sid" id="d_sid" required>
					</div>
					<button type="submit" class="btn btn-success">delete record</button>
				</div>
			</form>

			<div class="container bg-light">
				<form action="ViewRecords.php" method="post">
					<button type="submit" class="btn btn-success collapse" id="View">View records</button>
				</form>
			</div>




		</div>
</div>
</div>



	<div class="col-md-6">
		<div class="card">
			<img src="../assets/images/card2.jpg" class="card-img-top" alt="...">
				<div class="card-body">
				   <h5 class="card-title">Faculties</h5>
				   <p class="card-text">Perform Admin operations on Faculties</p>
		</div>
		<div class="container">
			<p class="p-2">
				<a class="btn btn-danger" data-toggle="collapse" href="#insertionF">Insert</a>
				<a class="btn btn-danger" data-toggle="collapse"	href="#deletionF">Delete</a>
				<a class="btn btn-danger" data-toggle="collapse"	href="#ViewF">View Records</a>
			</p>


			<form action="F_insertion.php" method="post">
				<div class="collapse bg-light p-5 m-3 rounded" id="insertionF">
					<h2 class="display-4 text-monospace">Enter the details of the Faculty to be added</h2>
					<div class="form-group">
						<label for="F_FName">Enter Faculty's First Name:</label>
						<input type="text" name="F_FName" class="form-control" id="F_FName" required>
					</div>
					<div class="form-group">
						<label for="F_LName">Enter Faculty's Last Name:</label>
						<input type="text" name="F_LName" class="form-control" id="F_LName" required>
					</div>
					<div class="form-group">
						<label for="F_Mail">Enter Mail:</label>
						<input type="email" name="F_Mail" class="form-control" id="F_Mail" required>
					</div>
					<div class="form-group">
						<label for="F_Sub">Enter Subject Undertaking:</label>
						<input type="text" name="F_Sub" class="form-control" id="F_Sub" required>
					</div>
					<div class="form-group">
						<label for="F_ASub">Enter Additional Subject Undertaking:</label>
						<input type="text" name="F_ASub" class="form-control" id="F_ASub" required>
					</div>
					<div class="form-group">
						<label for="F_Phone">Enter Phone number:</label>
						<input type="phone" name="F_Phone" class="form-control" id="F_Phone" required>
					</div>
					<div class="form-group">
						<label for="F_Class">Select Class:</label>
						<select id="F_Class" class="form-control" name="F_Class">
							<option selected>8</option>
							<option>9</option>
							<option>10</option>
						</select>
					</div>
					<button type="submit" class="btn btn-success">submit</button>
				</div>
			</form>

			<form action="F_deletion.php" method="post">
				<div class="collpse bg-light p-5 m-3 rounded" id="deletionF">
					<h2 class="display-4 text-monospace">Enter the details of the Faculty to be deleted from the database</h2>
					<div class="form-group">
						<label for="fac_id">Enter the Faculty id:</label>
						<input type="text" class="form-control" name="fac_id" required id="fac_id">
					</div>
					<button type="submit" class="btn btn-success">delete record</button>
				</div>
			</form>

			<div class="container bg-light">
				<form action="ViewRecords.php" method="post">
					<button type="submit" class="btn btn-success collapse" id="ViewF">View records</button>
				</form>
			</div>

</div>
</div>

</div>
</div>

<?php include '../includes/footer.php'; ?>
