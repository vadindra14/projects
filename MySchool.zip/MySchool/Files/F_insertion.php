<?php include 'connection.php'; ?>
<?php 
$ffname = $_POST['F_FName'];
$flname = $_POST['F_LName'];
$fmail = $_POST['F_Mail'];
$fsub = $_POST['F_Sub'];
$fasub = $_POST['F_ASub'];
$fphone	= $_POST['F_Phone'];
$fclass = $_POST['F_Class'];


	// echo "$ffname,$flname,$fmail,$fsub,$fasub,$fphone,$fclass";
	$query = "select * from faculties where F_FName = '$ffname' and F_LName = '$flname'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$count	= mysqli_num_rows($result);

		if ($count == 1) {
		echo "<script>alert('faculty is already registered..')</script>";
		}else{
			$query_i = "insert into faculties(F_FName,F_LName,F_Mail,F_Sub,F_ASub,F_Phone,F_Class) values('$ffname','$flname','$fmail','$fsub','$fasub','$fphone','$fclass')";
			$result_i = mysqli_query($conn,$query_i);

			echo "<script>alert('new faculty is registered successfully..')</script>";			
		}

?>