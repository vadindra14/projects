<?php 
$servername = 'localhost';
$username = 'root';
$password = '';
$db_name = 'school_db';

$conn = mysqli_connect($servername,$username,$password,$db_name);

//  if(!$conn){
// 	echo "Could not connect to database..".mysqli_connect_error();
// }
// else{
// 	echo "Connected to database successfully";
// }  


?>