 <?php include '../includes/header.php'; ?>
 <?php include 'connection.php'; ?>
	<div class="container p-4">
		<form action="authenticate.php" method="post">
			<h2 class="display-4 p-2">Please Login to Continue..</h2>
 			<div class="form-group p-2">
 				<label for="user">Username:</label>
 				<input type="text" name="user" class="form-control" id="user" placeholder="Enter Your username here.." required>
			</div>
			<div class="form-group p-2">
				<label for="pass">Password:</label>
				<input type="password" name="pass" class="form-control" id="pass" placeholder="Enter Your password here.." required>
			</div>
			<button type="submit" class="btn btn-success m-2">login</button>
			<p class="text-muted p-2">Dont have an account? <a href="signup.php">Signup here</a></p>
		</form>
	</div>
 <?php include '../includes/footer.php'; ?>