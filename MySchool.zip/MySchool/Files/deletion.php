<?php include 'connection.php'; ?>
<?php 
$stud_id = $_POST['d_sid'];

echo "$stud_id";

$query = "select * from s_info where s_id = '$stud_id'";
			$result = mysqli_query($conn,$query);
			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
			$count	= mysqli_num_rows($result);

			if($count==0){
				echo "<script>alert('no such record exists..')</script>";
			}else{
				// echo "record deleted successfully";

				$query_d = "delete from s_info where s_id = '$stud_id'";
				$result_d = mysqli_query($conn,$query_d);

				echo "<script>alert('student record has been deleted..')</script>";
			}

?>