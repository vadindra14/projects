 <?php include '../includes/header.php'; ?>
 <?php include 'connection.php'; ?>
	<div class="container p-4">
		<form action="s_authenticate.php" method="post">
			<h2 class="display-4 p-2">Please Create an Account to Continue..</h2>
 			<div class="form-group p-2">
 				<label for="user">Username:</label>
 				<input type="text" name="suser" class="form-control" id="user" placeholder="Enter Your username here.." required>
			</div>
			<div class="form-group p-2">
				<label for="pass">Password:</label>
				<input type="password" name="spass" class="form-control" id="pass" placeholder="Enter Your password here.." required>
			</div>
			<div class="form-group p-2">
				<label for="cpass">Confirm Password:</label>
				<input type="password" name="scpass" class="form-control" id="cpass" placeholder="Enter Your password here.." required>
			</div>
			<button type="submit" class="btn btn-success m-2">Ceate Account</button>
			<p class="text-muted p-2">Already have an account? <a href="login.php">Login here</a></p>
		</form>
	</div>
 <?php include '../includes/footer.php'; ?>